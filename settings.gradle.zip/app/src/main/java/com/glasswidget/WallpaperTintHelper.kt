package com.glasswidget

import android.app.WallpaperColors
import android.content.Context
import android.graphics.Color
import android.os.Build

/**
 * 动态壁纸取色助手
 *
 * 作用：从系统当前壁纸提取主色调，供玻璃背景做 tint
 * 效果：玻璃颜色自动贴合壁纸底色，让 Widget 和桌面更融为一体
 *
 * Android 8.1+ (API 27+) 原生支持 WallpaperColors
 */
object WallpaperTintHelper {

    data class TintResult(
        val bgTint: Int,       // 玻璃底色 tint（半透明叠加到玻璃上）
        val textColor: Int,    // 文字色（根据底色自动反白/反黑）
        val isDarkTheme: Boolean
    )

    private const val PREFS_NAME = "glass_widget_prefs"
    private const val KEY_BG_TINT = "bg_tint"
    private const val KEY_TEXT_COLOR = "text_color"
    private const val KEY_IS_DARK = "is_dark_theme"

    // —— 主入口：获取 tint，优先读缓存，没有则实时取 ——
    fun getTint(context: Context): TintResult {
        // 先尝试实时取
        val live = readFromWallpaper(context)
        if (live != null) {
            save(context, live)
            return live
        }
        // 缓存兜底
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val bg = prefs.getInt(KEY_BG_TINT, Color.parseColor("#18FFFFFF"))
        val text = prefs.getInt(KEY_TEXT_COLOR, Color.parseColor("#E6FFFFFF"))
        val dark = prefs.getBoolean(KEY_IS_DARK, false)
        return TintResult(bg, text, dark)
    }

    /**
     * 从系统壁纸实时提取颜色
     */
    private fun readFromWallpaper(context: Context): TintResult? {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O_MR1) return null

        val manager = context.getSystemService(Context.WALLPAPER_SERVICE)
            as? android.app.WallpaperManager ?: return null

        val colors: WallpaperColors = try {
            manager.getWallpaperColors(WallpaperManager.FLAG_SYSTEM)
                ?: manager.getWallpaperColors(WallpaperManager.FLAG_LOCK)
                ?: return null
        } catch (_: Exception) { return null }

        val primary = colors.primaryColor.toArgb()
        val hint = colors.colorHints

        // 判断壁纸是深色还是浅色
        val isDark = hint and WallpaperColors.HINT_DARK_MASK != 0 ||
                (colors.hints and WallpaperColors.HINT_HEAVY_TEXT_MASK) != 0

        // 生成玻璃 tint：在壁纸主色上叠 10-15% 不透明度，保留壁纸底色又不失去玻璃质感
        val bgTint = if (isDark) {
            // 深色壁纸 → 玻璃底色叠一层深色半透明，再稍微加一点白色增加反光感
            composeColors(primary, Color.parseColor("#08FFFFFF"), 0.5f)
        } else {
            // 浅色壁纸 → 玻璃底色叠一层白色半透明，强化玻璃质感
            composeColors(primary, Color.parseColor("#18FFFFFF"), 0.5f)
        }

        // 文字色：深色背景用白字，浅色背景用深字
        val textColor = if (isDark)
            Color.parseColor("#F2FFFFFF")
        else
            Color.parseColor("#E0000000")

        return TintResult(bgTint, textColor, isDark)
    }

    /**
     * 简单的颜色混合：c1 * ratio + c2 * (1-ratio)
     */
    private fun composeColors(c1: Int, c2: Int, ratio: Float): Int {
        val r = ((Color.red(c1) * ratio) + (Color.red(c2) * (1 - ratio))).toInt().coerceIn(0, 255)
        val g = ((Color.green(c1) * ratio) + (Color.green(c2) * (1 - ratio))).toInt().coerceIn(0, 255)
        val b = ((Color.blue(c1) * ratio) + (Color.blue(c2) * (1 - ratio))).toInt().coerceIn(0, 255)
        val a = ((Color.alpha(c1) * ratio) + (Color.alpha(c2) * (1 - ratio))).toInt().coerceIn(0, 255)
        return Color.argb(a, r, g, b)
    }

    private fun save(context: Context, tint: TintResult) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putInt(KEY_BG_TINT, tint.bgTint)
            .putInt(KEY_TEXT_COLOR, tint.textColor)
            .putBoolean(KEY_IS_DARK, tint.isDarkTheme)
            .apply()
    }
}
