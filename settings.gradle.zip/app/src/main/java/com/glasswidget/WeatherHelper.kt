package com.glasswidget

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * 天气数据助手：和风天气免费 API
 *
 * 使用前请：
 * 1. 到 https://dev.qweather.com/ 免费注册获取 API Key（每天 1000 次调用够了）
 * 2. 把 API_KEY 替换成你自己的 Key
 * 3. CITY_ID 改成你所在城市的 ID（在和风天气文档里查，比如上海 101020100、广州 101280101）
 */
object WeatherHelper {

    // ⚠️ 在这里填入你自己的和风天气免费 Key
    private const val API_KEY = "YOUR_QWEATHER_KEY_HERE"
    // 默认北京，改成你所在的城市 ID
    private const val CITY_ID = "101010100"

    private const val PREFS_NAME = "glass_widget_prefs"
    private const val KEY_TEMP = "temp_celsius"
    private const val KEY_COND = "condition_text"
    private const val KEY_LAST_UPDATE = "last_update"
    // 天气缓存有效期：30 分钟
    private const val CACHE_TTL_MS = 30 * 60 * 1000L

    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    // 读取缓存
    fun getCached(context: Context): WeatherResult? {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val temp = prefs.getString(KEY_TEMP, null) ?: return null
        val cond = prefs.getString(KEY_COND, "") ?: ""
        val last = prefs.getLong(KEY_LAST_UPDATE, 0L)
        if (System.currentTimeMillis() - last > CACHE_TTL_MS) return null // 过期
        return WeatherResult(temp, cond)
    }

    // 刷新天气（异步，结果写入 SharedPreferences）
    fun refresh(context: Context, onDone: ((WeatherResult?) -> Unit)? = null) {
        if (API_KEY == "YOUR_QWEATHER_KEY_HERE") {
            onDone?.invoke(null)
            return
        }
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val url = "https://devapi.qweather.com/v7/weather/now?location=$CITY_ID&key=$API_KEY"
                val request = Request.Builder().url(url).build()
                client.newCall(request).execute().use { resp ->
                    if (!resp.isSuccessful) { onDone?.invoke(null); return@use }
                    val body = resp.body?.string() ?: run { onDone?.invoke(null); return@use }
                    val json = JSONObject(body)
                    val now = json.getJSONObject("now")
                    val temp = now.getString("temp")
                    val cond = now.optString("text", "")
                    save(context, temp, cond)
                    onDone?.invoke(WeatherResult(temp, cond))
                }
            } catch (_: Exception) {
                onDone?.invoke(null)
            }
        }
    }

    private fun save(context: Context, temp: String, cond: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TEMP, temp)
            .putString(KEY_COND, cond)
            .putLong(KEY_LAST_UPDATE, System.currentTimeMillis())
            .apply()
    }

    data class WeatherResult(val tempCelsius: String, val condition: String) {
        // 友好展示：只显示温度（Widget 空间有限），需要天气状况也可以改这里
        val displayText: String get() = "${tempCelsius}°C"
    }
}
