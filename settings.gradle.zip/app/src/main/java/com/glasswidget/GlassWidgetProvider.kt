package com.glasswidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.Intent.ACTION_WALLPAPER_CHANGED
import android.content.Intent.ACTION_SCREEN_ON
import android.os.Build
import android.provider.AlarmClock
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

/**
 * 液态玻璃时钟 Widget v2
 *
 * 新增能力（相对 v1）：
 *   ✅ 动态壁纸取色 tint（WallpaperColors API）
 *   ✅ 深色模式适配（values-night 自动生效）
 *   ✅ 点击交互：点时钟跳系统时钟 App，点温度跳天气 App
 *   ✅ OriginOS 4x7 超大尺寸布局
 */
class GlassWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        appWidgetIds.forEach { updateSingle(context, appWidgetManager, it) }
        scheduleWeatherAlarm(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        val action = intent.action ?: return

        val refreshActions = setOf(
            Intent.ACTION_TIME_TICK,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_LOCALE_CHANGED,
            AppWidgetManager.ACTION_APPWIDGET_UPDATE,
            Intent.ACTION_BOOT_COMPLETED,
            ACTION_WALLPAPER_CHANGED,   // ★ 壁纸变了 → 重新取 tint
            ACTION_SCREEN_ON            // ★ 亮屏 → 刷新
        )
        if (action in refreshActions || action == ACTION_WEATHER_ALARM) {
            refreshAll(context)
        }
        if (action == ACTION_WEATHER_ALARM) {
            WeatherHelper.refresh(context) { refreshAll(context) }
        }
    }

    override fun onEnabled(context: Context) {
        super.onEnabled(context)
        scheduleWeatherAlarm(context)
    }

    override fun onDisabled(context: Context) {
        super.onDisabled(context)
        cancelWeatherAlarm(context)
    }

    private fun refreshAll(context: Context) {
        val mgr = AppWidgetManager.getInstance(context)
        val ids = mgr.getAppWidgetIds(
            ComponentName(context, GlassWidgetProvider::class.java)
        )
        ids.forEach { updateSingle(context, mgr, it) }
    }

    // ================================================================
    // 核心：更新单个 Widget
    // ================================================================
    private fun updateSingle(
        context: Context,
        mgr: AppWidgetManager,
        id: Int
    ) {
        // 1️⃣ 选布局
        val views = pickLayout(context, mgr, id)

        // 2️⃣ 取壁纸 tint + 文字色（动态）
        val tint = WallpaperTintHelper.getTint(context)

        // 3️⃣ 时钟
        val now = Calendar.getInstance()
        val timeFmt = SimpleDateFormat("HH:mm", Locale.getDefault())
        views.setTextViewText(R.id.tv_time, timeFmt.format(now.time))
        views.setTextColor(R.id.tv_time, tint.textColor)

        // 4️⃣ 日期（根据布局尺寸选不同格式）
        val layoutId = views.layoutId
        when (layoutId) {
            R.layout.widget_glass_2x2 -> {
                // 2x2 极简版：只有时钟 + 温度
            }
            R.layout.widget_glass_4x2 -> {
                val dateFmt = SimpleDateFormat("M/d E", Locale.CHINESE)
                views.setTextViewText(R.id.tv_date, dateFmt.format(now.time))
                views.setTextColor(R.id.tv_date, tint.textColor)
            }
            R.layout.widget_glass_4x4 -> {
                val dateFmt = SimpleDateFormat("M月d日 EEEE", Locale.CHINESE)
                views.setTextViewText(R.id.tv_date, dateFmt.format(now.time))
                views.setTextColor(R.id.tv_date, tint.textColor)
            }
            R.layout.widget_glass_4x7 -> {
                val dateFmt = SimpleDateFormat("M月d日 EEEE", Locale.CHINESE)
                views.setTextViewText(R.id.tv_date, dateFmt.format(now.time))
                views.setTextColor(R.id.tv_date, tint.textColor)
                // 4x7 额外显示天气状况文字
                val cached = WeatherHelper.getCached(context)
                val desc = cached?.condition?.takeIf { it.isNotBlank() } ?: ""
                views.setTextViewText(
                    R.id.tv_weather_desc,
                    if (desc.isBlank()) "点击查看天气详情" else desc
                )
                views.setTextColor(R.id.tv_weather_desc, tint.textColor)
            }
        }

        // 5️⃣ 温度
        val cached = WeatherHelper.getCached(context)
        val weatherText = cached?.displayText ?: context.getString(R.string.no_weather)
        views.setTextViewText(R.id.tv_weather, weatherText)
        views.setTextColor(R.id.tv_weather, tint.textColor)

        // 6️⃣ ★ 点击交互
        applyOnClickListeners(context, views)

        mgr.updateAppWidget(id, views)
    }

    // ================================================================
    // ★ 点击交互：点不同区域跳不同 App
    // ================================================================
    private fun applyOnClickListeners(context: Context, views: RemoteViews) {
        // —— 点时钟区域 → 打开系统时钟 App（闹钟/秒表）——
        val clockIntent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val clockPI = PendingIntent.getActivity(
            context,
            1001,
            clockIntent,
            pendingIntentFlags()
        )
        views.setOnClickPendingIntent(R.id.tv_time, clockPI)

        // —— 点日期区域 → 打开系统日历 App ——
        val calendarIntent = Intent(Intent.ACTION_VIEW).apply {
            data = android.provider.CalendarContract.CONTENT_URI
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val calPI = PendingIntent.getActivity(
            context,
            1002,
            calendarIntent,
            pendingIntentFlags()
        )
        // 所有布局都有 tv_date（2x2 除外）
        if (views.layoutId != R.layout.widget_glass_2x2) {
            try { views.setOnClickPendingIntent(R.id.tv_date, calPI) } catch (_: Exception) {}
        }

        // —— 点温度区域 → 打开系统天气 App（找不到则走浏览器搜索）——
        val weatherIntent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_APP_WEATHER)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val weatherPI = PendingIntent.getActivity(
            context,
            1003,
            weatherIntent,
            pendingIntentFlags()
        )
        views.setOnClickPendingIntent(R.id.tv_weather, weatherPI)

        // —— 点 4x7 的天气描述文字也触发天气跳转 ——
        if (views.layoutId == R.layout.widget_glass_4x7) {
            try { views.setOnClickPendingIntent(R.id.tv_weather_desc, weatherPI) } catch (_: Exception) {}
        }
    }

    private fun pendingIntentFlags(): Int {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        else
            PendingIntent.FLAG_UPDATE_CURRENT
    }

    // ================================================================
    // 布局选择（增加 4x7 判断）
    // ================================================================
    private fun pickLayout(
        context: Context,
        mgr: AppWidgetManager,
        id: Int
    ): RemoteViews {
        val opts = mgr.getAppWidgetOptions(id)
        val h = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT, 180)
        val w = opts.getInt(AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH, 180)

        // vivo OriginOS 标准基准：4x7 ≈ 590dp
        return when {
            h >= 480 -> RemoteViews(context.packageName, R.layout.widget_glass_4x7)
            h <= 180 && w <= 180 -> RemoteViews(context.packageName, R.layout.widget_glass_2x2)
            h <= 180 -> RemoteViews(context.packageName, R.layout.widget_glass_4x2)
            else -> RemoteViews(context.packageName, R.layout.widget_glass_4x4)
        }
    }

    // ================================================================
    // 定时刷新天气的 AlarmManager
    // ================================================================
    private fun scheduleWeatherAlarm(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = weatherPendingIntent(context)
        val firstTrigger = System.currentTimeMillis() + 60_000L

        am.setExactAndAllowWhileIdle(AlarmManager.RTC, firstTrigger, pi)
        am.setInexactRepeating(
            AlarmManager.RTC,
            firstTrigger,
            30 * 60 * 1000L,
            pi
        )
    }

    private fun cancelWeatherAlarm(context: Context) {
        val am = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(weatherPendingIntent(context))
    }

    private fun weatherPendingIntent(context: Context): PendingIntent {
        val intent = Intent(context, GlassWidgetProvider::class.java).apply {
            action = ACTION_WEATHER_ALARM
        }
        return PendingIntent.getBroadcast(context, 0, intent, pendingIntentFlags())
    }

    companion object {
        private const val ACTION_WEATHER_ALARM = "com.glasswidget.WEATHER_ALARM"
    }
}
