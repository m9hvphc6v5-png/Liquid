package com.glasswidget

import android.os.Bundle
import android.app.Activity

/**
 * 宿主 Activity（必需，但内容可以极简）
 * 安装后点击图标会打开，什么都不做——Widget 本身就是全部
 */
class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 立即关闭，用户不会看到这个 Activity
        finish()
    }
}
