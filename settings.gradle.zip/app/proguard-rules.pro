# 液态玻璃 Widget 不需要混淆
-keep class com.glasswidget.** { *; }
-dontwarn okhttp3.**
-dontwarn okio.**
